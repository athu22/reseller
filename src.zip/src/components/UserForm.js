import { useState } from 'react';
import { database, ref, set, get, update } from '../firebase';
import { useNavigate } from 'react-router-dom';

const UserForm = ({ softwareId }) => {
  const [form, setForm] = useState({ username: '', password: '' });
  const [userData, setUserData] = useState(null);
  const [userId, setUserId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    try {
      const snapshot = await get(ref(database, 'users'));
      const users = snapshot.val() || {};
      let found = null;
      let foundId = null;
  
      Object.entries(users).forEach(([uid, user]) => {
        if (user.username === form.username) {
          found = user;
          foundId = uid;
        }
      });
  
      if (found) {
        // User already exists, show info
        setUserData(found);
        setUserId(foundId);
      } else {
        // New user — create and redirect to wallet page
        const newId = Date.now().toString();
        const newUser = {
          username: form.username,
          password: form.password,
          createdAt: new Date().toISOString(),
          softwareId,
          walletPoints: 0,
        };
  
        await set(ref(database, 'users/' + newId), newUser);
        navigate(`/wallet/${newId}?softwareId=${softwareId}`);
      }
    } catch (err) {
      console.error('Error:', err);
      alert('Something went wrong!');
    } finally {
      setLoading(false);
    }
  };
  

  const handleRecharge = async () => {
    const amount = parseInt(rechargeAmount);
    if (!isNaN(amount) && amount > 0 && userId) {
      const newPoints = (userData.walletPoints || 0) + amount;
      await update(ref(database, 'users/' + userId), {
        walletPoints: newPoints
      });

      setUserData({ ...userData, walletPoints: newPoints });
      setRechargeAmount('');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow mb-6">
        <h2 className="text-xl font-bold mb-4">Create or Check User</h2>
        <input
          name="username"
          type="text"
          placeholder="Username"
          value={form.username}
          onChange={handleChange}
          className="block w-full border px-3 py-2 mb-3 rounded"
          required
        />
        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          className="block w-full border px-3 py-2 mb-4 rounded"
          required
        />
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded w-full hover:bg-blue-600"
          disabled={loading}
        >
          {loading ? 'Checking...' : 'Submit'}
        </button>
      </form>

      {userData && (
        <div className="bg-green-100 p-4 rounded shadow text-sm">
          <h3 className="text-lg font-semibold mb-2">User Info</h3>
          <p><strong>User ID:</strong> {userId}</p>
          <p><strong>Username:</strong> {userData.username}</p>
          <p><strong>Software ID:</strong> {userData.softwareId || 'None'}</p>
          <p><strong>Wallet Points:</strong> {userData.walletPoints || 0}</p>

          <div className="mt-4">
            <input
              type="number"
              placeholder="Recharge Amount"
              value={rechargeAmount}
              onChange={(e) => setRechargeAmount(e.target.value)}
              className="w-full border px-3 py-2 mb-2 rounded"
            />
            <button
              onClick={handleRecharge}
              className="bg-yellow-500 text-white px-4 py-2 rounded w-full hover:bg-yellow-600"
            >
              Recharge Wallet
            </button>
          </div>

          <button
            onClick={() => navigate(`/activation/${userId}/${softwareId}`)}
            className="mt-4 bg-purple-500 text-white px-4 py-2 rounded w-full hover:bg-purple-600"
          >
            Go to Activation
          </button>
        </div>
      )}
    </div>
  );
};

export default UserForm;
