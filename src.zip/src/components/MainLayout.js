import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Home, UserPlus, User } from 'lucide-react';

const MainLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="min-h-screen pb-16"> {/* Space for bottom menu */}
      <Outlet />

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white shadow-md border-t flex justify-around items-center py-2 md:hidden z-50">
        <button
          className={`flex flex-col items-center text-sm ${location.pathname === '/' ? 'text-blue-600' : ''}`}
          onClick={() => navigate('/')}
        >
          <Home size={20} />
          <span>Software</span>
        </button>
        <button
          className={`flex flex-col items-center text-sm ${location.pathname.startsWith('/create-user') ? 'text-blue-600' : ''}`}
          onClick={() => navigate('/create-user/1')} // default software ID or change as needed
        >
          <UserPlus size={20} />
          <span>Create</span>
        </button>
        <button
          className={`flex flex-col items-center text-sm ${location.pathname === '/profile' ? 'text-blue-600' : ''}`}
          onClick={() => navigate('/profile')}
        >
          <User size={20} />
          <span>Profile</span>
        </button>
      </div>
    </div>
  );
};

export default MainLayout;
