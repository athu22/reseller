import { useNavigate } from 'react-router-dom';

const SoftwareCard = ({ software }) => {
  const navigate = useNavigate();

  return (
    <div className="border p-4 rounded shadow">
      <h2>{software.name}</h2>
      <p>{software.description}</p>
      <button
        onClick={() => navigate(`/create-user/${software.id}`)}
        className="mt-2 bg-blue-500 text-white px-4 py-2 rounded"
      >
        Buy
      </button>
    </div>
  );
};

export default SoftwareCard;
