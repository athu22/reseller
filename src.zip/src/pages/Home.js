// Home.jsx
import softwareList from '../data/softwareList';
import SoftwareCard from '../components/SoftwareCard';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { HomeIcon, UserPlusIcon, UserIcon } from 'lucide-react';

const Home = () => {
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  const filteredSoftware = softwareList.filter((software) =>
    software.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen">
      <div className="p-4 flex-1">
        <div className="sticky top-0 z-10 bg-white p-4 shadow mb-4 rounded flex items-center">
          <input
            type="text"
            placeholder="Search software..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 border border-gray-300 rounded px-4 py-2 focus:outline-none"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredSoftware.map((software) => (
            <SoftwareCard key={software.id} software={software} />
          ))}
        </div>
      </div>

      {/* Bottom Navbar for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-inner p-2 flex justify-around items-center sm:hidden">
        <button onClick={() => navigate('/')} className="flex flex-col items-center text-gray-700">
          <HomeIcon size={24} />
          <span className="text-xs">Software</span>
        </button>
        <button onClick={() => navigate('/create-user/1')} className="flex flex-col items-center text-gray-700">
          <UserPlusIcon size={24} />
          <span className="text-xs">Create User</span>
        </button>
        <button onClick={() => navigate('/profile')} className="flex flex-col items-center text-gray-700">
          <UserIcon size={24} />
          <span className="text-xs">Profile</span>
        </button>
      </div>
    </div>
  );
};

export default Home;
