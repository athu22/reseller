export default [
    { id: 1, name: 'Software A', description: 'Powerful tool for X' },
    { id: 2, name: 'Software B', description: 'Designed for Y' },
  ];
  